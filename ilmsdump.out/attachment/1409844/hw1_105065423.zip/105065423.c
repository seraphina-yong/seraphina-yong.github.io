#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/slab.h> /* for memory mgmt */

/* struct for student ID and birthday */
typedef struct _IDbirthday {
    struct list_head list;
    int id;
    int year;
    int month;
    int day;
}IDbirthday;

/* use macro */
LIST_HEAD(bdaylist);

/* This function is called when the module is loaded. */
int birthdays_init(void)
{
    printk(KERN_INFO "Loading Module\n");    

    IDbirthday *tmp;
    IDbirthday *tmp2;
    int studentIDs[5] = {106062541, 105062841, 104052142, 103543212, 101021242};
    int i;
    for (i=0; i<5; i++) {
        tmp = kmalloc(sizeof(*tmp), GFP_KERNEL);
        
        (*tmp).id = studentIDs[i];
        (*tmp).year = 1990 - i;
        (*tmp).month = 1 + i;
        (*tmp).day = 23 - i;
        
        INIT_LIST_HEAD(&(*tmp).list);
        list_add(&(*tmp).list, &bdaylist);
    }

    /* print constructed list */
    printk(KERN_INFO "Printing constructed list\n");
    /* use reverse to print list in order */
    list_for_each_entry_reverse(tmp2, &bdaylist, list) {
        printk(KERN_INFO "%d, %d-%d-%d\n",
            (*tmp2).id,
            (*tmp2).day,
            (*tmp2).month,
            (*tmp2).year);
    }
    printk(KERN_INFO "Finished printing constructed list\n");

    return 0;
}

/* This function is called when the module is removed. */
void birthdays_exit(void)
{
    printk(KERN_INFO "Removing Module\n");

    IDbirthday *cursor;
    IDbirthday  *tmp;
    /* allow for memory freeing during traversal */
    list_for_each_entry_safe_reverse(cursor, tmp, &bdaylist, list) {
        printk(KERN_INFO "Removing %d, %d-%d-%d\n",
            (*cursor).id,
            (*cursor).day,
            (*cursor).month,
            (*cursor).year);
        list_del(&(*cursor).list);
        kfree(cursor);
    }
    
    printk(KERN_INFO "Freed list\n");
}

/* Macros for registering module entry and exit points. */
module_init(birthdays_init);
module_exit(birthdays_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Birthday List Module");
MODULE_AUTHOR("Seraphina");
